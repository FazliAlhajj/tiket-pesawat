<?php

session_start();

if(!isset($_SESSION["username"])){
    echo "
        <script type='text/javascript'>
            alert('Silahkan login terlebih dahulu ya!');
            window.location = '../auth/login/'
        </script>
    ";
}

?>

<?php require '../layouts/sidebar_admin.php'; ?>
<link rel="stylesheet" href="../../assets/style/sidebar.css">
<div class="ucapan">
<h1>Halo, <?= $_SESSION["nama_lengkap"]; ?></h1>
<h3>Semoga kamu mendapatkan penerbangan yang aman, damai, dan benar-benar nyaman!.</h3>
</div>
