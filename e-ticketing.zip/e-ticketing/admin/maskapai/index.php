<?php

$page = 'Maskapai';
session_start();
require 'function.php';

if(!isset($_SESSION["username"])){
    echo "
        <script type='text/javascript'>
            alert('Silahkan login terlebih dahulu ya!');
            window.location = '../auth/login/'
        </script>
    ";
}

$maskapai = query("SELECT * FROM maskapai");

?>

<?php require '../../layouts/sidebar_admin.php'; ?>

<link rel="stylesheet" href="../../assets/style/sidebar.css">
<div class="tabel-maskapai">
    <h1>Data maskapai | E - Ticketing</h1>
    <a href="tambah.php">Tambah</a><br><br> 
    <table border="1" cellpadding="10" cellspacing="0">
        <tr>
            <th>No</th>
            <th>Logo Maskapai</th>
            <th>nama maskapai</th>
            <th>Kapasitas</th>
            <th>Aksi</th>
        </tr>

        <?php $no = 1; ?>
        <?php foreach($maskapai as $data) : ?>
            <tr>
                <td><?= $no; ?></td>
                <td><img src="../../assets/images/<?= $data["logo_maskapai"]; ?>" width="100"></td>
                <td><?= $data["nama_maskapai"]; ?></td>
                <td><?= $data["kapasitas"]; ?></td>
                <td>
                    <a href="edit.php?id=<?= $data["id_maskapai"]; ?>">Edit</a>
                    <a href="hapus.php?id=<?= $data["id_maskapai"]; ?>" onClick="return confirm('Apakah ANda yakin ingin menghapus data ini?')">Hapus</a>
                </td>
            </tr>
        <?php $no++; ?>
        <?php endforeach; ?>    
    </table>
</div>
