<?php
require 'functions.php';
session_start();

if(!isset($_SESSION["username"])){
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu, ya!');
        window.location = '../auth/login/index.php';
    </script>
    ";
}

$orderTiket = query("SELECT * FROM order_tiket")

?>

<?php require '../../layouts/sidebar_admin.php'; ?>

<h1>Halo, <?= $_SESSION["nama_lengkap"]; ?></h1>

<div class="content" style="margin-left: 150px; margin-top: 50px;">
<h1>Data Pemesanan Tiket</h1>
<table border="1" cellpadding="10" cellspacing="0">
    <tr>
        <th>Nomor Order</th>
        <th>Struk</th>
        <th>Status</th>
        <th>Opsi</th>
    </tr>
    <?php foreach($orderTiket as $data) : ?>
        <tr>
            <td><?= $data["id_order"]; ?></td>
            <td><?= $data["struk"]; ?></td>
            <td>
            <?php 
                if($data["status"] == "Proses"){
                    ?>
                    <a href="update_status.php?id=<?= $data["id_order"]; ?>" style="color: blue; text-decoration: none;">Proses</a>
                    <?php
                } else if($data["status"] == "Berhasil"){
                    ?>
                    <a href="" style="color: green; text-decoration: none;">Berhasil</a>
                    <?php
                } else if($data["status"] == "Gagal"){
                    ?>
                    <a href="" style="color: red; text-decoration: none;">Gagal</a>
                    <?php
                }
            ?>
            </td>
            <td>
                <button class="btn btn-primary"><a href="verif.php?id=<?= $data["id_order"]; ?>">Verifikasi</a></button>
                <a href="reject.php?id=<?= $data["id_order"]; ?>">Reject</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
</div>