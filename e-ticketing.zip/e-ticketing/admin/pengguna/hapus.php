<?php

require 'function.php';

$id = $_GET["id"];


if(hapus($id) > 0){
    echo"
        <script type=text/javascript>
            alert('YAy! Data pengguna Berhasil Di Hapus');
            window.location = 'index.php';
        </script>
    ";
}else{
    echo"
        <script typw=text/javascript>
            alert('Yha... Data pengguna Gagal Di Hapus');
            window.location = 'index.php';
        </script>
    ";
}

?>