<?php
$page = 'Pengguna';
session_start();
require 'function.php';

if(!isset($_SESSION["username"])){
    echo "
        <script type='text/javascript'>
            alert('Silahkan login terlebih dahulu ya!');
            window.location = '../auth/login/'
        </script>
    ";
}

$pengguna = query("SELECT * FROM user WHERE roles = 'Petugas' || roles ='Penumpang'");

?>

<?php require '../../layouts/sidebar_admin.php'; ?>

<link rel="stylesheet" href="../../assets/style/sidebar.css">

<div class="tabel-admin" style="margin-right:50px;">
    <h1>Data pengguna | E - Ticketing</h1>
    <a href="tambah.php">Tambah</a>
    <table border="2" cellpadding="10" cellspacing="0">
        <tr>
            <th>No</th>
            <th>Username</th>
            <th>Nama lengkap</th>
            <th>Roles</th>
            <th>Aksi</th>
        </tr>

        <?php $no = 1; ?>
        <?php foreach($pengguna as $data) : ?>
            <tr>
                <td><?= $no; ?></td>
                <td><?= $data["username"]; ?></td>
                <td><?= $data["nama_lengkap"]; ?></td>
                <td><?= $data["roles"]; ?></td>
                <td>
                    <a href="edit.php?id=<?= $data["id_user"]; ?>">Edit</a>
                    <a href="hapus.php?id=<?= $data["id_user"]; ?>" onClick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</a>
                </td>
            </tr>
        <?php $no++; ?>
        <?php endforeach; ?>    
    </table>
</div>