<?php

require 'layouts/navbar.php';
if(!isset($_SESSION["username"])){
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu, ya!');
        window.location = 'index.php';
    </script>
    ";
}

?>

<?php if(empty($_SESSION["cart"])) {
    ?>
    <h1>LIST PEMESANAN KOSONG ! </h1>
    <?php
}else{
?>
    <div class="wrapper-keranjang">
        <h1 style="font-family:'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;">LIST PEMESANAN TIKET</h1>


<div class="keranjang">
            <table border="1" cellpadding="10" cellspacing="0">
                <tr>
                    <th style="background-color:#EFF396;">No</th>
                    <th style="background-color:#EFF396;">Nama maskapai</th>
                    <th style="background-color:#EFF396;">Rute</th>
                    <th style="background-color:#EFF396;">Tanggal Keberangkatan</th>
                    <th style="background-color:#EFF396;">Harga</th>
                    <th style="background-color:#EFF396;">Kapasitas</th>
                    <th style="background-color:#EFF396;">Total Harga</th>
                </tr>

                <?php $i = 1; ?>
                <?php $grandtotal = 0; ?>
                <?php foreach ($_SESSION["cart"] as $id_order => $kapasitas) :
                    $order = query("SELECT * FROM jadwal_penerbangan 
                                    INNER JOIN rute ON rute.id_rute = jadwal_penerbangan.id_rute 
                                    INNER JOIN maskapai ON rute.id_maskapai = maskapai.id_maskapai 
                                    WHERE jadwal_penerbangan.id_jadwal = $id_order")[0];

                    $totalharga = $order["harga"] * $kapasitas;
                    $grandtotal += $totalharga;
                    ?>
                    <tr>
                        <td><?= $i; ?></td>
                        <td><?= $order["nama_maskapai"]; ?></td>
                        <td><?= $order["rute_asal"] ?> - <?= $order["rute_tujuan"]; ?></td>
                        <td><?= date("Y-m-d", strtotime($order["tanggal_pergi"])); ?></td>
                        <td><?= number_format($order["harga"]); ?></td>
                        <td><?= $kapasitas; ?></td>
                        <td><?= number_format($totalharga); ?></td>
                    </tr>
                <?php $i++; ?>
                <?php endforeach; ?>

                <tr>
                        <td>Grand Total</td>
                        <td colspan="5">Rp. <?= number_format($grandtotal); ?></td><br>
                        <td colspan="6"><a href="checkout.php" style="width: 100%; text-align:center; background-color:#337357;">Checkout</a></td>
                </tr>
            </table>
        </div>
    </div>
<?php
}
?>