<?php

require 'layouts/navbar.php';

if(!isset($_SESSION["username"])){
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu, ya!');
        window.location = 'index.php';
    </script>
    ";
}

$id = $_GET["id"];

$tiket = query("SELECT * FROM jadwal_penerbangan 
INNER JOIN rute ON rute.id_rute = jadwal_penerbangan.id_rute 
INNER JOIN maskapai ON rute.id_maskapai = maskapai.id_maskapai WHERE id_jadwal = '$id'")[0];

?>

<div class="detail-penerbangan" style="background-color: blue; margin-left:25px; margin-right:25px; border-radius:20px;" >
    <h1>Detail Penerbangan</h1>
    <div class="wrapper-detail-penerbangan">
        <form action="" method="post">
            <img src="assets/images/<?= $tiket["logo_maskapai"]; ?>" width="200">    
            <p>Nama Maskapai : <?= $tiket["nama_maskapai"]; ?></p>
            <p>Rute Penerbangan : <?= $tiket["rute_asal"] ?> - <?= $tiket["rute_tujuan"]; ?></p>
             <label for="tanggal_pergi">Tanggal Pergi = <?= $tiket["tanggal_pergi"]; ?></label>
            <p>Rp. <?= number_format($tiket["harga"]); ?></p>
           
            <input type="number" name="qty" value="1"><br/><br>
            <button type="submit" name="kirim">Tambahkan ke Keranjang</button>
        </form>
    </div>
</div>

<?php

if(isset($_POST["kirim"])){
    if($_POST["qty"] > $tiket["kapasitas_kursi"]){
        echo "
            <script type='text/javascript'>
                alert('Maaf, Kuantitas kamu melebihi stok yang tersedia');
                window.location = 'index.php';
            </script>
        ";
    }elseif ($_POST["qty"]<= 0){
        echo "
            <script type='text/javascript'>
                alert('Silahkan Tambahkan produk lebih dahulu');
                window.location = 'index.php';
            </script>
        ";
    }else{
        $qty = $_POST["qty"];
        $_SESSION["cart"][$id] = $qty;

        echo "
            <script type='text/javascript'>
                alert('Tiket berhasil ditambahkan');
                window.location = 'cart.php';
            </script>
        ";
    }
}


?>