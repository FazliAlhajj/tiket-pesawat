<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/e-ticketing/assets/style/sidebar.css">
    <title>Petugas</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
    <div class="w3-sidebar w3-bar-block btn btn-warning" style="width:250px;">
        <h2 class="w3-bar-block">Tabel Petugas</h2>
        <a href="../index.php" class="w3-bar-item w3-button"><i class=""></i>Dashboard</a>&nbsp;&nbsp;
        
        <a href="/tiket-pesawat/e-ticketing/petugas/kota" class="w3-bar-item w3-button"><i class="fa-solid fa-city"></i> Data Kota</a>
        <a href="/tiket-pesawat/e-ticketing/petugas/rute" class="w3-bar-item w3-button"><i class="fa-solid fa-route"></i> Data Rute</a>
        <a href="/tiket-pesawat/e-ticketing/petugas/jadwal" class="w3-bar-item w3-button"><i class="fa-solid fa-calendar-days"></i> Data Jadwal Penerbangan </a>
        <a href="../logout.php" class="w3-bar-item w-3-button" onClick="return confirm('Apakah anda yakin ingin logout?');" style="border: 2px solid red; background-color: blueviolet ; text-decoration: none; border-radius: 7px;">Logout</a>
    </div> 
</body>
</html>