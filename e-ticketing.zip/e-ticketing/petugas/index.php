<?php

session_start();

if(!isset($_SESSION["username"])){
    echo "
        <script type='text/javascript'>
            alert('Silahkan login terlebih dahulu ya!');
            window.location = '../auth/login/'
        </script>
    ";
}

?>

<?php require '../layouts/sidebar_petugas.php'; ?>
<h1 style="margin-left:250px;">Halo, <?= $_SESSION["nama_lengkap"]; ?></h1>
<h2 style="margin-left:250px;">Selamat Datang</h2>